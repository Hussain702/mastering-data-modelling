# Databricks notebook source
spark.sql(f""" 
            SELECT *,
               date(current_timestamp()) as processed_date
            FROM datamodelling.bronze.bronze_table
           
            """).createOrReplaceTempView('silver_source')
          

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM silver_source

# COMMAND ----------

if spark.catalog.tableExists('datamodelling.silver.silver_table'):
    spark.sql(""" 
              MERGE INTO datamodelling.silver.silver_table AS target
              USING silver_source AS source
              ON target.order_id = source.order_id
              WHEN MATCHED THEN
                UPDATE SET *
              WHEN NOT MATCHED
                THEN INSERT *
              """)
else:
    spark.sql("""
      CREATE TABLE IF NOT EXISTS datamodelling.silver.silver_table
      AS
      SELECT * FROM silver_source""")
 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT * FROM datamodelling.silver.silver_table

# COMMAND ----------

# MAGIC %md
# MAGIC **DIM_PAYMENTS**

# COMMAND ----------

