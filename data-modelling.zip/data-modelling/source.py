# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS datamodelling.default.source_data (
# MAGIC     order_id INT PRIMARY KEY,
# MAGIC     order_date DATE,
# MAGIC     customer_id INT,
# MAGIC     customer_name VARCHAR(100),
# MAGIC     customer_email VARCHAR(100),
# MAGIC     product_id INT,
# MAGIC     product_name VARCHAR(100),
# MAGIC     product_category VARCHAR(50),
# MAGIC     quantity INT,
# MAGIC     unit_price DECIMAL(10,2),
# MAGIC     payment_type VARCHAR(50),
# MAGIC     country VARCHAR(50),
# MAGIC     last_updated DATE
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO datamodelling.default.source_data VALUES
# MAGIC (1, '2024-01-01', 101, 'Ali Khan', 'ali@gmail.com', 201, 'Laptop', 'Electronics', 1, 800.00, 'Credit Card', 'Pakistan', '2024-01-01'),
# MAGIC
# MAGIC (2, '2024-01-02', 102, 'Sara Ahmed', 'sara@gmail.com', 202, 'Phone', 'Electronics', 2, 500.00, 'Debit Card', 'Pakistan', '2024-01-02'),
# MAGIC
# MAGIC (3, '2024-01-03', 103, 'John Smith', 'john@gmail.com', 203, 'Shoes', 'Fashion', 3, 70.00, 'Cash', 'USA', '2024-01-03'),
# MAGIC
# MAGIC (4, '2024-01-04', 104, 'Emma Watson', 'emma@gmail.com', 204, 'Watch', 'Accessories', 1, 150.00, 'Credit Card', 'UK', '2024-01-04'),
# MAGIC
# MAGIC (5, '2024-01-05', 105, 'David Lee', 'david@gmail.com', 205, 'Bag', 'Fashion', 2, 120.00, 'PayPal', 'Canada', '2024-01-05'),
# MAGIC
# MAGIC (6, '2024-01-06', 106, 'Ayesha Noor', 'ayesha@gmail.com', 206, 'Headphones', 'Electronics', 1, 90.00, 'Debit Card', 'Pakistan', '2024-01-06'),
# MAGIC
# MAGIC (7, '2024-01-07', 107, 'Michael Brown', 'michael@gmail.com', 207, 'Tablet', 'Electronics', 1, 300.00, 'Credit Card', 'USA', '2024-01-07'),
# MAGIC
# MAGIC (8, '2024-01-08', 108, 'Fatima Ali', 'fatima@gmail.com', 208, 'Dress', 'Fashion', 2, 60.00, 'Cash', 'Pakistan', '2024-01-08'),
# MAGIC
# MAGIC (9, '2024-01-09', 109, 'Chris Evans', 'chris@gmail.com', 209, 'Camera', 'Electronics', 1, 700.00, 'PayPal', 'USA', '2024-01-09'),
# MAGIC
# MAGIC (10, '2024-01-10', 110, 'Zain Malik', 'zain@gmail.com', 210, 'Shoes', 'Fashion', 1, 80.00, 'Credit Card', 'Pakistan', '2024-01-10');

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM datamodelling.default.source_data

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO datamodelling.default.source_data VALUES
# MAGIC (1, '2024-01-11', 101, 'Hussain Ali', 'ali@gmail.com', 201, 'Laptop', 'Electronics', 1, 800.00, 'Credit Card', 'Pakistan', '2024-01-11')