# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE datamodelling.default.products
# MAGIC (
# MAGIC   prod_id STRING,
# MAGIC   prod_name STRING,
# MAGIC   prod_category STRING,
# MAGIC   processed_date TIMESTAMP
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO datamodelling.default.products
# MAGIC VALUES
# MAGIC ('P001', 'Product 1', 'Category 1', current_timestamp()),
# MAGIC ('P002', 'Product 2', 'Category 2', current_timestamp()),
# MAGIC ('P003', 'Product 3', 'Category 3', current_timestamp());
# MAGIC     
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM 
# MAGIC   datamodelling.default.products 

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE datamodelling.gold.products
# MAGIC (
# MAGIC   prod_id STRING,
# MAGIC   prod_name STRING,
# MAGIC   prod_category STRING,
# MAGIC   processed_date TIMESTAMP,
# MAGIC   start_date TIMESTAMP,
# MAGIC   end_date TIMESTAMP,
# MAGIC   is_expired STRING
# MAGIC
# MAGIC )

# COMMAND ----------

spark.sql(""" SELECT *,
               current_timestamp() as start_date,
               CAST('1900-01-01' AS timestamp) as end_date,
               'y' as is_expired
               FROM datamodelling.default.products """).createOrReplaceTempView('src')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM src

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO datamodelling.gold.products AS trg
# MAGIC USING src
# MAGIC ON trg.prod_id = src.prod_id
# MAGIC WHEN MATCHED AND(
# MAGIC   trg.prod_name <> src.prod_name OR
# MAGIC   trg.prod_category <> src.prod_category OR
# MAGIC   trg.processed_date <> src.processed_date
# MAGIC ) THEN UPDATE SET
# MAGIC   trg.end_date=current_timestamp(),
# MAGIC   trg.is_expired='n'
# MAGIC  
# MAGIC
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM datamodelling.gold.products

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO datamodelling.gold.products AS trg
# MAGIC USING src
# MAGIC ON trg.prod_id = src.prod_id
# MAGIC AND trg.is_expired='y'
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC   prod_id,
# MAGIC   prod_name,
# MAGIC   prod_category,
# MAGIC   processed_date,
# MAGIC   start_date,
# MAGIC   end_date,
# MAGIC   is_expired
# MAGIC )
# MAGIC VALUES (
# MAGIC   src.prod_id,
# MAGIC   src.prod_name,
# MAGIC   src.prod_category,
# MAGIC   src.processed_date,
# MAGIC   src.start_date,
# MAGIC   src.end_date,
# MAGIC   src.is_expired
# MAGIC )
# MAGIC     
# MAGIC
# MAGIC
# MAGIC     
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE datamodelling.default.products
# MAGIC SET prod_category='new_cat'
# MAGIC WHERE prod_id='P001'
# MAGIC     
# MAGIC