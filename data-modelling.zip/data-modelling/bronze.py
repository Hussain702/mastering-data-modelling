# Databricks notebook source
last_upload_date = spark.sql("""SELECT MAX(last_updated) FROM datamodelling.bronze.bronze_table""").collect()[0][0]

# COMMAND ----------

last_upload_date

# COMMAND ----------

spark.sql(f""" 
            SELECT * FROM datamodelling.default.source_data
            WHERE order_date > '{last_upload_date}'
            """).createOrReplaceTempView('bronze_source')
          

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE datamodelling.bronze.bronze_table
# MAGIC AS
# MAGIC SELECT * FROM bronze_source

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM datamodelling.bronze.bronze_table

# COMMAND ----------

