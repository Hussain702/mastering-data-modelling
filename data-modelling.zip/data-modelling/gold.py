# Databricks notebook source
# MAGIC %md
# MAGIC **DIM_CUSTOMERS**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE datamodelling.gold.dim_customer
# MAGIC AS
# MAGIC WITH rem_dup AS(
# MAGIC   SELECT 
# MAGIC    DISTINCT(customer_id),
# MAGIC    customer_name,
# MAGIC    customer_email
# MAGIC    FROM datamodelling.silver.silver_table
# MAGIC )
# MAGIC SELECT *, row_number() OVER(ORDER BY customer_id) AS DimCustomerKey
# MAGIC FROM rem_dup
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **DIM_PRODUCTS**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE datamodelling.gold.dim_product
# MAGIC AS
# MAGIC WITH rem_dup AS(
# MAGIC   SELECT 
# MAGIC    DISTINCT(product_id),
# MAGIC    product_name,
# MAGIC    product_category
# MAGIC    FROM datamodelling.silver.silver_table
# MAGIC )
# MAGIC SELECT *, row_number() OVER(ORDER BY product_id) AS DimProductKey
# MAGIC FROM rem_dup
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **DIM_PAYMENTS**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE datamodelling.gold.dim_payments
# MAGIC AS
# MAGIC WITH rem_dup AS(
# MAGIC   SELECT 
# MAGIC    DISTINCT(payment_type)
# MAGIC    
# MAGIC    FROM datamodelling.silver.silver_table
# MAGIC )
# MAGIC SELECT *, row_number() OVER(ORDER BY payment_type) AS DimPaymentKey
# MAGIC FROM rem_dup
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **DIM_REGIONS**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE datamodelling.gold.dim_regions
# MAGIC AS
# MAGIC WITH rem_dup AS(
# MAGIC   SELECT 
# MAGIC    DISTINCT(country)
# MAGIC    FROM datamodelling.silver.silver_table
# MAGIC )
# MAGIC SELECT *, row_number() OVER(ORDER BY country) AS DimRegionKey
# MAGIC FROM rem_dup
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **DIM_SALES**

# COMMAND ----------

spark.sql("""  SELECT * FROM datamodelling.silver.silver_table """).columns

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE datamodelling.gold.dim_sales
# MAGIC AS
# MAGIC  SELECT
# MAGIC  row_number() OVER (ORDER BY order_id) AS DimSalesKey,
# MAGIC  order_id,
# MAGIC  order_date,
# MAGIC  customer_id,
# MAGIC  customer_name,
# MAGIC  customer_email,
# MAGIC  product_id,
# MAGIC  product_name,
# MAGIC  product_category,
# MAGIC  payment_type,
# MAGIC  country,
# MAGIC  last_updated,
# MAGIC  processed_date
# MAGIC FROM datamodelling.silver.silver_table 

# COMMAND ----------

# MAGIC %md
# MAGIC **FACT TABLE**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE datamodelling.gold.fact_sales
# MAGIC AS
# MAGIC SELECT 
# MAGIC
# MAGIC  c.DimCustomerKey,
# MAGIC  p.DimProductKey,
# MAGIC  py.DimPaymentKey,
# MAGIC  r.DimRegionKey,
# MAGIC  s.DimSalesKey,
# MAGIC  f.quantity,
# MAGIC  f.unit_price
# MAGIC FROM datamodelling.silver.silver_table AS f 
# MAGIC LEFT JOIN datamodelling.gold.dim_customer AS c ON f.customer_id = c.customer_id
# MAGIC LEFT JOIN datamodelling.gold.dim_product AS p ON f.product_id = p.product_id
# MAGIC LEFT JOIN datamodelling.gold.dim_payments AS py ON f.payment_type = py.payment_type
# MAGIC LEFT JOIN datamodelling.gold.dim_regions AS r ON f.country = r.country
# MAGIC LEFT JOIN datamodelling.gold.dim_sales AS s ON f.order_id = s.order_id