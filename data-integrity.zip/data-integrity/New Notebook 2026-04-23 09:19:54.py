# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE source_a(
# MAGIC   cust_id INT,
# MAGIC   name STRING,
# MAGIC   city STRING
# MAGIC );
# MAGIC
# MAGIC INSERT INTO source_a VALUES 
# MAGIC (101, 'ALI','LAHORE'),
# MAGIC (102,'SULTAN','ISB');

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM source_a

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE source_b(
# MAGIC   customer_id INT,
# MAGIC   full_name STRING,
# MAGIC   location STRING
# MAGIC );
# MAGIC
# MAGIC INSERT INTO source_b VALUES 
# MAGIC (101, 'ALI','LAHORE'),
# MAGIC (102,'SULTAN','ISB'),
# MAGIC (103,'HASSAN','ISB');
# MAGIC     
# MAGIC SELECT * FROM source_b
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE source_c(
# MAGIC   id INT,
# MAGIC   name STRING,
# MAGIC   region STRING,
# MAGIC   contact STRING
# MAGIC );
# MAGIC INSERT INTO source_c VALUES
# MAGIC (101,'ALI','LAHORE','03000000000'),
# MAGIC (102,'SULTAN','ISB','03000000001'),
# MAGIC (103,'HASSAN','ISB','03000000002');
# MAGIC
# MAGIC SELECT * FROM source_c
# MAGIC     
# MAGIC

# COMMAND ----------

customer_id,
name,
city,
phone

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE t_src_a
# MAGIC AS
# MAGIC SELECT 
# MAGIC  cust_id AS customer_id,
# MAGIC  name,
# MAGIC  city,
# MAGIC  CAST (NULL AS STRING) AS phone
# MAGIC  FROM source_a
# MAGIC
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM t_src_a

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE t_src_b
# MAGIC AS
# MAGIC SELECT 
# MAGIC  customer_id AS customer_id,
# MAGIC  full_name AS name,
# MAGIC  location AS city,
# MAGIC  CAST (NULL AS STRING) AS phone
# MAGIC  FROM source_b
# MAGIC
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE t_src_c
# MAGIC AS
# MAGIC SELECT 
# MAGIC  id AS customer_id,
# MAGIC  name,
# MAGIC  region AS city,
# MAGIC  contact AS phone
# MAGIC  FROM source_c
# MAGIC
# MAGIC   
# MAGIC     
# MAGIC
# MAGIC
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM t_src_c

# COMMAND ----------

df_unified=spark.sql("""
          SELECT *
          FROM t_src_a
          UNION
          SELECT *
          FROM t_src_b
          UNION
          SELECT* 
          FROM t_src_c
          
          """).createOrReplaceTempView('UNIFIED_SCHEMA')

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC     SELECT * FROM unified_schema

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE unified_schema_table
# MAGIC AS
# MAGIC SELECT customer_id, name, city, coalesce(phone,'UNKNOWN') AS phone
# MAGIC FROM UNIFIED_SCHEMA

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM unified_schema_table

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH de_dup AS(
# MAGIC
# MAGIC     SELECT *,
# MAGIC     ROW_NUMBER() OVER(PARTITION BY customer_id ORDER BY customer_id) AS rn
# MAGIC     FROM UNIFIED_SCHEMA
# MAGIC )
# MAGIC SELECT *
# MAGIC FROM de_dup
# MAGIC WHERE rn=1

# COMMAND ----------

